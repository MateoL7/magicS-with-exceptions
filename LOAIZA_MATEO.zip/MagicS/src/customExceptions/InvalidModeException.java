package customExceptions;

@SuppressWarnings("serial")
public class InvalidModeException extends Exception{
	public InvalidModeException(int pMode) {
		super("The number for the mode of the square cannot be odd");
	}
}
