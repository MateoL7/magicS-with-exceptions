package customExceptions;

@SuppressWarnings("serial")
public class InvalidOrientationException extends Exception{
	public InvalidOrientationException(String pOrientation) {
		super("");
	}
}
