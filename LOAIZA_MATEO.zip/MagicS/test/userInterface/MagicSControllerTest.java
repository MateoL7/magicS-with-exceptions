package userInterface;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MagicSControllerTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
