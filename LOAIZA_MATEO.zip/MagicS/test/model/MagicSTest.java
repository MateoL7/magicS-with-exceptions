package model;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;

import org.junit.jupiter.api.Test;

import customExceptions.InvalidModeException;

class MagicSTest {
	
	private MagicS magicS;
	
	private void setupScenary1() {
		
	}
	private void setupScenary2() {
		int [][] testSquare = new int[3][3];
		magicS.setSquare(testSquare); 
	}

	@Test
	void testMagicS() {
		setupScenary1();
		
		int pMode = 3;
		
		MagicS mS;
		try {
			mS = new MagicS(pMode);
			assertNotNull("The new magic square is null", mS);
			assertTrue("The new magic square is not empty", mS.getSquare().length == 0);
		} catch (InvalidModeException e) {
			e.getMessage();
		}
	}
	public MagicS getMagicS() {
		return magicS;
	}
	public void setMagicS(MagicS magicS) {
		this.magicS = magicS;
	}
	
	@Test
	void testGetMagicS() {
		setupScenary2();
		int [][] testSquare2 = new int [3][3];
		assertTrue("The method is returning a wrong value", Arrays.deepEquals(testSquare2, magicS.getSquare())) ;
		
	}
	@Test
	void testFillSquare(int pMode, String pLocation, String pOrientation) {
		setupScenary1();
		
	}

}
